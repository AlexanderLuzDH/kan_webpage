{
    "name": "CFT Odoo Pro",
    "summary": "BOM explosion and multi-company enhancements for CFT (paid)",
    "version": "17.0.1.0.0",
    "author": "Busleyden",
    "license": "OEEL-1",
    "website": "https://www.busleyden.com",
    "depends": ["cft_odoo", "mrp"],
    "data": [],
    "installable": True,
}

