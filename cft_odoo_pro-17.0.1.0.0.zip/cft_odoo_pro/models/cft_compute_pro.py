from odoo import api, models, fields
from collections import defaultdict


class CftComputePro(models.AbstractModel):
    _inherit = "cft.compute"

    def _collect_upstream(self, company_id):
        # run core to get PO/MO
        res = super()._collect_upstream(company_id)
        # add single-level BOM explosion (Pro)
        bom_impacts = self._trace_bom_components(company_id, res)
        for product_id, impacts in bom_impacts.items():
            res[product_id].extend(impacts)
        return res

    def _trace_bom_components(self, company_id, upstream_by_product):
        bom_impacts = defaultdict(list)
        if not self.env.registry.get('mrp.bom'):
            return bom_impacts
        BOM = self.env['mrp.bom']
        for component_id, shortage_events in upstream_by_product.items():
            if not shortage_events:
                continue
            boms = BOM.search([
                ('bom_line_ids.product_id', '=', component_id),
                ('active', '=', True),
            ])
            for bom in boms:
                bom_lines = bom.bom_line_ids.filtered(lambda l: l.product_id.id == component_id)
                for bom_line in bom_lines:
                    for event in shortage_events:
                        impact_qty = float(event.get('qty', 0.0)) * float(bom_line.product_qty or 1.0)
                        if impact_qty <= 0:
                            continue
                        finished_product = bom.product_id
                        list_price = float(finished_product.lst_price or finished_product.list_price or 0.0)
                        bom_impacts[finished_product.id].append({
                            "t": event.get("t"),
                            "qty": impact_qty,
                            "base_w": impact_qty * list_price,
                            "type": "bom_component",
                            "label": f"{bom.name}: {event.get('product')} shortage → {finished_product.display_name}",
                            "ref": f"{bom.name}",
                            "supplier": event.get('supplier'),
                            "product": finished_product.display_name,
                            "id": bom.id,
                            "component_product_id": component_id,
                            "finished_product_id": finished_product.id,
                            "key": f"bom:{bom.id}:component:{component_id}",
                            "root_cause": event.get('key'),
                        })
        return bom_impacts


