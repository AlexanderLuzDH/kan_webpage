from odoo import http
from odoo.http import request


def _auth_ok(req):
    token = (req.httprequest.headers.get('Authorization') or '').replace('Bearer ', '')
    cfg = request.env['cft.config']._get_for_company(request.env.company.id)
    return bool(token and cfg.api_token and token == cfg.api_token)


class CftApiController(http.Controller):
    @http.route('/cft/api/v1/orders/<int:so_id>/risk', type='json', auth='none', methods=['GET'])
    def order_risk(self, so_id):
        if not _auth_ok(request):
            return http.Response(status=401)
        so = request.env['sale.order'].sudo().browse(so_id)
        if not so:
            return http.Response(status=404)
        return {
            'order_id': so.id,
            'name': so.name,
            'revenue_at_risk': so.x_cft_revenue_risk,
            'exposure_pct': so.x_cft_exposure_score,
            'top_causes_json': so.x_cft_top_causes_json,
            'last_computed': so.x_cft_last_computed,
        }


