{
    "name": "CFT Odoo Enterprise",
    "summary": "Enterprise features: recursive BOM, API & webhooks (paid)",
    "version": "17.0.1.0.0",
    "author": "Busleyden",
    "license": "OEEL-1",
    "website": "https://www.busleyden.com",
    "depends": ["cft_odoo_pro", "mrp", "base"],
    "data": [],
    "installable": True,
}

