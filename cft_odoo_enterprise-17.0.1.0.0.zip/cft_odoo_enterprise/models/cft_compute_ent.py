from odoo import models
from collections import defaultdict


class CftComputeEnterprise(models.AbstractModel):
    _inherit = "cft.compute"

    def _collect_upstream(self, company_id):
        # core + pro
        res = super()._collect_upstream(company_id)
        # add recursive propagation for enterprise
        bom_impacts = self._trace_bom_components_recursive(company_id, res, max_depth=6)
        for product_id, impacts in bom_impacts.items():
            res[product_id].extend(impacts)
        return res

    def _trace_bom_components_recursive(self, company_id, upstream_by_product, max_depth=6):
        bom_impacts = defaultdict(list)
        if not self.env.registry.get('mrp.bom'):
            return bom_impacts
        comp_to_parents = defaultdict(list)
        for bl in self.env['mrp.bom.line'].search([('bom_id.product_id.company_id', '=', company_id)]):
            comp_to_parents[bl.product_id.id].append((bl.bom_id.product_id.id, float(bl.product_qty or 1.0), bl.bom_id))

        def propagate(component_id, event, depth, visited):
            if depth > max_depth or component_id in visited:
                return
            visited.add(component_id)
            for parent_pid, qty_req, bom in comp_to_parents.get(component_id, []):
                impact_qty = float(event.get('qty', 0.0)) * qty_req
                if impact_qty <= 0:
                    continue
                parent_prod = self.env['product.product'].browse(parent_pid)
                list_price = float(parent_prod.lst_price or parent_prod.list_price or 0.0)
                bom_impacts[parent_pid].append({
                    "t": event.get("t"),
                    "qty": impact_qty,
                    "base_w": impact_qty * list_price,
                    "type": "bom_component",
                    "label": f"{bom.name}: {event.get('product')} shortage → {parent_prod.display_name}",
                    "ref": f"{bom.name}",
                    "supplier": event.get('supplier'),
                    "product": parent_prod.display_name,
                    "id": bom.id,
                    "component_product_id": component_id,
                    "finished_product_id": parent_pid,
                    "key": f"bom:{bom.id}:component:{component_id}",
                    "root_cause": event.get('key'),
                })
                propagate(parent_pid, {**event, 'qty': impact_qty, 'product': parent_prod.display_name}, depth + 1, visited.copy())

        for comp_id, events in upstream_by_product.items():
            for ev in events:
                propagate(comp_id, ev, 1, set())
        return bom_impacts


